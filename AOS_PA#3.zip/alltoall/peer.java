import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_DELETE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_MODIFY;
import static java.nio.file.StandardWatchEventKinds.OVERFLOW;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class peer {

	static String CONFIG_TTR = "./config/config0_TTR.txt";
	final static int UPDATE_TTL = 3;
	final static int _TTL = 3;
	final static String DOC_PATH = "./docs/";
	static String CONFIG_PATH = "./config/config0.txt";
	static String update_function;
	final static int START_SEARCH_PORT = 6410;
	
	public static void main(String[] args) throws Exception {
		if (args.length == 0) {
			update_function = "PUSH";
		} else {
			update_function = args[0];
		}

		BufferedReader bufferReader = new BufferedReader(new InputStreamReader(System.in));
		HashMap<String, ArrayList<String>> map = read_config(CONFIG_PATH);
		ArrayList<String> nbr_list = new ArrayList<String>();
		int nodes = map.size();
		
		message("---New Window Client End---");
		message("---Total Clients in the config are " + Integer.toString(nodes) + "---");
		message("---Enter the client sequece which starts from 1--- ");
		message("");

		String clientNumber = bufferReader.readLine();
		int portnumber = START_SEARCH_PORT + Integer.parseInt(clientNumber);
		nbr_list = map.get(clientNumber);

		String mfileDownlaoad = DOC_PATH + clientNumber + "/master/";
		ArrayList<String> masterFile = fileScan(mfileDownlaoad, clientNumber);

		String dFileFolder = DOC_PATH + clientNumber + "/downloaded/";
		ArrayList<String> download_filelst = fileScan(dFileFolder, clientNumber);

		HashMap<String, String> lastModifiedEntry = new HashMap<String, String>();

		FileWriter fileWriter = new FileWriter("PullServer.txt", true);

		synchronized (fileWriter) {

			for (int j = 0; j < masterFile.size(); j++) {
				String file_ = masterFile.get(j);
				fileWriter.write(file_ + ":" + clientNumber + "\n");
			}
			fileWriter.close();
		}

		HashMap<String, Integer> m_fileVersion = new HashMap<String, Integer>();
		HashMap<String, Integer> d_file_vrsn = new HashMap<String, Integer>();
		HashMap<String, String> fl_valid = new HashMap<String, String>();

		Instant inst = Instant.now();
		long time = inst.toEpochMilli();

		for (int j = 0; j < masterFile.size(); j++) {
			m_fileVersion.put(masterFile.get(j), 1);
			fl_valid.put(masterFile.get(j), "VALID");
			lastModifiedEntry.put(masterFile.get(j), String.valueOf(time));
		}

		for (int j = 0; j < download_filelst.size(); j++) {
			d_file_vrsn.put(download_filelst.get(j), 1);
			fl_valid.put(download_filelst.get(j), "VALID");
			lastModifiedEntry.put(download_filelst.get(j), String.valueOf(time));
		}

		Thread.sleep(1000);

		HashMap<String, String> nbrIP = setNbrIP(nbr_list);

		Runnable clientServer = new Peer2SearchServer(portnumber, clientNumber, nbrIP, d_file_vrsn,
				fl_valid, m_fileVersion, lastModifiedEntry);
		Thread clientServerThread = new Thread(clientServer);
		clientServerThread.start();

		Runnable client2Server = new ClientServer(clientNumber, clientNumber);
		Thread client2ServerThread = new Thread(client2Server);
		client2ServerThread.start();

		message(clientNumber +"@Client: Please enter YES once you start all the peers in this config-------");
		message(clientNumber +"@Client: You need to start " + Integer.toString(nodes) + " peers in this config-------");
		
		String read_ln = bufferReader.readLine();

		while (!read_ln.equals("YES")) {

			message(clientNumber +"@Client: Wrong Command Entered Please try again-------");
			message(
					clientNumber  +"@Client: Please type YES after you start all the peers in this config system. >>>");
			
			message(clientNumber +"@Client: You need to start " + Integer.toString(nodes)
					+ " peers in this config-------");
			message("");
			read_ln = bufferReader.readLine();
		}

		HashMap<String, String> server_Download_Map = read_Master("PullServer.txt");

		String set_TTR = read_config_TTR(CONFIG_TTR, clientNumber);
		message(clientNumber +"@Client: My TTR = " + set_TTR + " seconds.");
		message("");

		if (update_function.equals("PULL")) {
			// Start Pull Thread
			ClientPullUpdate clientPullupdate = new ClientPullUpdate(set_TTR, clientNumber, server_Download_Map, d_file_vrsn,
					fl_valid);
			Thread P2PUThread = new Thread(clientPullupdate);
			P2PUThread.start();
		}

		// File change monitor thread
		FileChangeMonitor fileChangeMonitor = new FileChangeMonitor(clientNumber, update_function, mfileDownlaoad,
				m_fileVersion, nbrIP, lastModifiedEntry);
		Thread fileChangeThread = new Thread(fileChangeMonitor);
		fileChangeThread.start();

		Runnable runnable = new UpdateThread(set_TTR, clientNumber, fl_valid, nbrIP);
		Thread runnableThread = new Thread(runnable);
		runnableThread.start();

		for (String string : nbrIP.keySet()) {
			message(clientNumber + clientNumber +"@Client: Your have neighbors: " + string + " with IP: " + nbrIP.get(string));
			message("");
		}

		message(clientNumber+"@Client: Use command 'SEARCH FILENAME' to search file in system---");
		message(clientNumber+"@Client: The files are from doc_1.txt - doc_30.txt------");
		message("");
		String readLine = bufferReader.readLine();
		int j = 0;
		while (true) {

			if (readLine.split(" ")[0].equals("SEARCH")) {
				String fl_name = readLine.split(" ")[1];

				ArrayList<String> fl_lst = new ArrayList<String>();
				fl_lst.addAll(fileScan(mfileDownlaoad, clientNumber));
				fl_lst.addAll(fileScan(dFileFolder, clientNumber));
				if (fl_lst.contains(fl_name) && fl_valid.get(fl_name).equals("VALID")) {
					message("");
					message(clientNumber +"@Client: You already has this file locally as our LEAF node with newest version -------");
					message(clientNumber +"@Client: Please input the command again -------");
					message(clientNumber+"@Client: Use command 'SEARCH FILENAME' to search file in system---");
					message(clientNumber+"@Client: The files are from doc_1.txt - doc_30.txt------");
					message("");

					readLine = bufferReader.readLine();
					continue;
				}

				String message_ID = clientNumber + "##" + Integer.toString(j);
				j++;

				message(clientNumber +"@Client: Sending requests to your neighbors");
				message("");
				sendRequestNbr(nbrIP, fl_name, message_ID, clientNumber);
			} else if (readLine.split(" ")[0].equals("PRINT")) {
				for (String key : m_fileVersion.keySet()) {
					message(clientNumber +"@Client: Your has master files: " + key + " with version number: "
							+ m_fileVersion.get(key));
					message("");
				}
				for (String key : d_file_vrsn.keySet()) {
					message(clientNumber +"@Client: Your has downloaded files: " + key + " with version number: "
							+ d_file_vrsn.get(key));
					message("");
				}
				for (String key : fl_valid.keySet()) {
					message(clientNumber +"@Client: Your has the files: " + key + " with version number: "
							+ fl_valid.get(key));
					message("");
				}

				for (String string : lastModifiedEntry.keySet()) {
					message(clientNumber +"@Client: Your has the files: " + string
							+ " with last modified timestamp: " + lastModifiedEntry.get(string));
					message("");
				}

			} else if (readLine.split(" ")[0].equals("UPDATE")) {

				readLine = readLine.replace("UPDATE", "SEARCH");
				continue;

			} else {

				message(clientNumber +"@Client: You typed wront command.");
				message("");
			}

			Thread.sleep(1000);
			message(clientNumber +"@Client: Please input the command again-------");
			message(clientNumber +"@Client: Use command 'SEARCH FILENAME' to search file in system---");
			message(clientNumber +"@Client: The files are from doc_1.txt - doc_30.txt------");
			readLine = bufferReader.readLine();
		}
	}

	public static HashMap<String, ArrayList<String>> read_config(String ConfigFile) {

		message("Reading the Configuration file to observe the details of Neighbouring Clients");
		message("");

		HashMap<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();
		try {
			File file = new File(ConfigFile);
			synchronized (file) {
				FileReader fileReader = new FileReader(file);
				BufferedReader reader = new BufferedReader(fileReader);
				StringBuffer sb = new StringBuffer();
				String string;

				while ((string = reader.readLine()) != null) {

					String[] lstLine = string.split(":");
					String keyName = lstLine[0];
					String mapValue = lstLine[1];

					String[] nbr_LST = mapValue.split(",");
					ArrayList<String> arrayList = new ArrayList<String>(Arrays.asList(nbr_LST));

					map.put(keyName, arrayList);
				}
				fileReader.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map;
	}

	public static ArrayList<String> fileScan(String fp, String NumID) {
		ArrayList<String> list_files = new ArrayList<String>();
		File[] fileList = new File(fp).listFiles();
		for (int i = 0; i < fileList.length; i++) {
			list_files.add(fileList[i].getName());
		}
		return list_files;
	}

	public static HashMap<String, String> setNbrIP(ArrayList<String> nbrlist) {

		HashMap<String, String> mapnbr = new HashMap<String, String>();
		for (int i = 0; i < nbrlist.size(); i++) {
			mapnbr.put(nbrlist.get(i), "127.0.0.1");
		}

		return mapnbr;
	}

	@SuppressWarnings("resource")
	public static void sendRequestNbr(HashMap<String, String> nbrIP, String filenm, String message,
			String currentClientId) throws Exception {

		for (String key : nbrIP.keySet()) {

			int current_port = Integer.parseInt(key) + START_SEARCH_PORT;
			String query = "QUERY%" + message + "%" + Integer.toString(_TTL) + "%" + filenm + "%"
					+ currentClientId;
			String current_ip = nbrIP.get(key);
			workSocket(current_ip, current_port, query);
		}

	}

	public static String read_config_TTR(String ConfigFile, String NumID) {
		HashMap<String, String> hmap = new HashMap<String, String>();
		try {
			File file = new File(ConfigFile);
			synchronized (file) {
				FileReader fileReader = new FileReader(file);
				BufferedReader reader = new BufferedReader(fileReader);
				StringBuffer sb = new StringBuffer();
				String string;

				while ((string = reader.readLine()) != null) {

					String[] lstLine = string.split(":");
					String keyName = lstLine[0];
					String mapValues = lstLine[1];

					hmap.put(keyName, mapValues);
				}
				fileReader.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return hmap.get(NumID);
	}

	public static HashMap<String, String> read_Master(String ConfigFile) {

		HashMap<String, String> hmap = new HashMap<String, String>();

		try {
			File file = new File(ConfigFile);

			synchronized (file) {

				FileReader fileReader = new FileReader(file);
				BufferedReader reader = new BufferedReader(fileReader);
				StringBuffer sb = new StringBuffer();
				String string;

				while ((string = reader.readLine()) != null) {

					String[] lstLine = string.split(":");
					String keyName = lstLine[0];
					String mapValues = lstLine[1];

					hmap.put(keyName, mapValues);
				}
				fileReader.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return hmap;
	}
	public static void message(String str) {
		System.out.println(str);
	}
	
	public static void workSocket(String IP, int port, String query)
			throws UnknownHostException, IOException {
		Socket socket;
		socket = new Socket(IP, (port));
		BufferedReader input;
		input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		PrintStream output;
		output = new PrintStream(socket.getOutputStream());

		output.println(query);
		output.flush();
		socket.close();

	}
}

	

	class FileChangeMonitor implements Runnable {

		final static int TTL_UPDATE = 3;
		final static int START_SEARCH_PORT = 6410;

		String clientID;
		String filePath;
		HashMap<String, Integer> MasterfVserio;
		String update_method;
		HashMap<String, String> nbrIP;
		HashMap<String, String> modify;

		FileChangeMonitor(String clientID, String method_update, String fp, HashMap<String, Integer> mFileV,
				HashMap<String, String> nbrIP, HashMap<String, String> modify) {

			this.clientID = clientID;
			this.filePath = fp;
			this.MasterfVserio = mFileV;
			this.update_method = method_update;
			this.nbrIP = nbrIP;
			this.modify = modify;

		}

		public String getUpdateMethod() {
			System.out.println("Test Code"+update_method);
			return update_method;
		}

		public void setUpdateMethod(String updateMethod) {
			this.update_method = updateMethod;
		}

		@Override
		public void run() {
			try {
				WatchService watcherService = FileSystems.getDefault().newWatchService();
				Path path = Paths.get(this.filePath);
				path.register(watcherService, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);

				message("-------Client: Watch Service registered for peer: " + clientID);
				message("");
				int j = 0;
				while (true) {
					WatchKey watchKey;
					try {
						watchKey = watcherService.take();
					} catch (Exception ex) {
						return;
					}

					for (WatchEvent<?> event : watchKey.pollEvents()) {
						WatchEvent.Kind<?> watchEventKind = event.kind();
						@SuppressWarnings("unchecked")
						WatchEvent<Path> wathcEvent = (WatchEvent<Path>) event;
						Path fileName = wathcEvent.context();

						DateTimeFormatter dateTime = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
						LocalDateTime localTime = LocalDateTime.now();
						message(this.clientID +"@Client: " + dateTime.format(localTime));
						message("");
						message(this.clientID +"@Client: " + watchEventKind.name() + ": " + fileName);
						message("");

						if (watchEventKind == OVERFLOW) {
							continue;
						} else if (watchEventKind == ENTRY_CREATE) {
						} else if (watchEventKind == ENTRY_DELETE) {
						} else if (watchEventKind == ENTRY_MODIFY) {
							Instant instant = Instant.now();
							long timem = instant.toEpochMilli();
							message(String.valueOf(timem));
							MasterfVserio.put(fileName.toString(), MasterfVserio.get(fileName.toString()) + 1);
							modify.put(fileName.toString(), String.valueOf(timem));
							if (this.getUpdateMethod().equals("PULL")) {
								message(this.clientID +"@Client: Now it is PULL method to update");
								message("");

							} else if (this.getUpdateMethod().equals("PUSH")) {

								message(this.clientID +"@Client: Now it is PUSH method to update");
								message("");
								// Propagate the messages to neighbors.
								invalidateNbr(nbrIP, fileName.toString(), Integer.toString(j),
										this.clientID);
							}
						}
					}

					// IMPORTANT: The key must be reset after processed
					boolean valid = watchKey.reset();
					if (!valid) {
						break;
					}
					j += 1;
				}

			} catch (IOException ex) {
				System.err.println(ex);
			}

		}

		private void message(String string) {
		System.out.println(string);	
		}

		public void invalidateNbr(HashMap<String, String> nbrip, String fl, String message,
				String currentid) throws IOException {

			for (String key : nbrip.keySet()) {

				int current_port = Integer.parseInt(key) + START_SEARCH_PORT;
				String current_ip = nbrip.get(key);
				String query = "INVALIDATE%" + message + "%" + Integer.toString(TTL_UPDATE) + "%" + fl
						+ "%" + currentid + "%" + this.MasterfVserio.get(fl);
				workSocket(current_ip, current_port, query);
			}
		}
		
		public static void workSocket(String IP, int port, String query)
				throws UnknownHostException, IOException {
			Socket socket;
			socket = new Socket(IP, (port));
			BufferedReader input;
			input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintStream output;
			output = new PrintStream(socket.getOutputStream());

			output.println(query);
			output.flush();
			socket.close();

		}
}

	class Peer2SearchServer implements Runnable {

		int portnumer;
		ArrayList<String> listQuery;
		HashMap<String, Integer> master_File;
		String clientID;
		HashMap<String, String> nbrIP;
		HashMap<String, Integer> d_fileVErsion;
		HashMap<String, String> lastModify;
		HashMap<String, String> isValid;

		Peer2SearchServer(int portnumber, String NumID, HashMap<String, String> neighbor_IP,
				HashMap<String, Integer> d_FileVersion, HashMap<String, String> FileValid,
				HashMap<String, Integer> m_FileVersion, HashMap<String, String> FileLastModify) {

			this.portnumer = portnumber;
			this.clientID = NumID;
			this.d_fileVErsion = d_FileVersion;
			this.nbrIP = neighbor_IP;
			this.master_File = m_FileVersion;
			this.lastModify = FileLastModify;
			this.isValid = FileValid;
		}

		public static ArrayList<String> fileScan(String fp) {

			ArrayList<String> list_files = new ArrayList<String>();
			File[] fileList = new File(fp).listFiles();
			for (int i = 0; i < fileList.length; i++) {
				list_files.add(fileList[i].getName());
			}
			return list_files;
		}

		@Override
		public void run() {
			// TODO Auto-generated method stub

			try {
				ServerSocket socket_req = new ServerSocket(portnumer);
				message(clientID+"@Client: I'm waiting for your searching query request.");
				message(" ");

				HashMap<String, String> map = new HashMap<String, String>();
				HashMap<String, Integer> hitmap = new HashMap<String, Integer>();
				ArrayList<String> datainvalidate = new ArrayList<String>();

				while (true) {

					Socket socket = socket_req.accept();
					Runnable peer2searchquery = new Peer2SearchQuery(socket, clientID, nbrIP, map,
							hitmap, d_fileVErsion, datainvalidate, isValid, master_File,
							lastModify);
					Thread peer2searchqueryThread = new Thread(peer2searchquery);
					peer2searchqueryThread.start();
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		private void message(String string) {
			System.out.println(string);
			
		}
}

	class Peer2SearchQuery implements Runnable {

		Socket QuerySocket;
		String NumID;
		ArrayList<String> FileList;
		HashMap<String, String> neighbor_IP;
		static HashMap<String, Integer> DownloadFileVersion;

		static HashMap<String, String> Query_map;
		static HashMap<String, Integer> Queryhit_map;
		static ArrayList<String> MessageIDInvalidate;
		static HashMap<String, String> FileValid;
		static HashMap<String, Integer> MasterFileVersion;
		static HashMap<String, String> FileLastModify;

		final static int START_SEARCH_PORT = 6410;
		final static int STARTING_FILE_REQUEST_PORT = 6530;
		final static int STARTING_FILE_PORT = 6650;
		final static String DOC_PATH = "./docs/";

		String My_IP;
		String My_PORT;

		Peer2SearchQuery(Socket QuerySocket, String NumID, HashMap<String, String> neighbor_IP,
				HashMap<String, String> Query_map, HashMap<String, Integer> Queryhit_map,
				HashMap<String, Integer> DownloadFileVersion, ArrayList<String> MessageIDInvalidate,
				HashMap<String, String> FileValid, HashMap<String, Integer> MasterFileVersion,
				HashMap<String, String> FileLastModify) {

			this.QuerySocket = QuerySocket;
			this.NumID = NumID;
			this.neighbor_IP = neighbor_IP;
			this.My_IP = "127.0.0.1";

			Peer2SearchQuery.DownloadFileVersion = DownloadFileVersion;
			Peer2SearchQuery.Query_map = Query_map;
			Peer2SearchQuery.Queryhit_map = Queryhit_map;
			Peer2SearchQuery.MessageIDInvalidate = MessageIDInvalidate;
			Peer2SearchQuery.FileValid = FileValid;
			Peer2SearchQuery.MasterFileVersion = MasterFileVersion;
			Peer2SearchQuery.FileLastModify = FileLastModify;
		}

		@Override
		public void run() {
			try {
				BufferedReader bufferReader = new BufferedReader(new InputStreamReader(QuerySocket.getInputStream()));
				PrintWriter out = new PrintWriter(QuerySocket.getOutputStream(), true);
				String resp = "";
				String ip = QuerySocket.getRemoteSocketAddress().toString();
				resp = bufferReader.readLine();
				String[] requestInfo = resp.split("%");

				if (requestInfo[0].equals("QUERY")) {

					String msgID = requestInfo[1];
					int currentTTL = Integer.parseInt(requestInfo[2]) - 1;
					String Filename = requestInfo[3];
					String Previous_senderNumID = requestInfo[4];

					String Previous_sender_IP = neighbor_IP.get(Previous_senderNumID);
					String Previous_sender_PORT = Integer
							.toString(Integer.parseInt(Previous_senderNumID) + START_SEARCH_PORT);
					String Previous_sender_IP_PORT = Previous_sender_IP + ":" + Previous_sender_PORT;

					// Didn't see this messageID before
					if (!Query_map.containsKey(msgID)) {

						Query_map.put(msgID, Previous_sender_IP_PORT);

						String path_temp = DOC_PATH + this.NumID + "/";
						String Master_Path = DOC_PATH + NumID + "/master/";
						String Download_Path = DOC_PATH + NumID + "/downloaded/";
						FileList = new ArrayList<String>();
						FileList.addAll(fileScan(Master_Path));
						FileList.addAll(fileScan(Download_Path));
						if (FileList.contains(Filename) && FileValid.get(Filename).equals("VALID")) {

							message(this.NumID + "@Client: We have this file " + Filename + " <<<");
							message("");
							message(this.NumID + "@Client: We are sending the queryhit message back <<<");
							message("");

							ArrayList<String> MasterFileList = fileScan(Master_Path);
							ArrayList<String> DownloadFileList = fileScan(Download_Path);
							int version_num;
							if (MasterFileList.contains(Filename)) {
								version_num = MasterFileVersion.get(Filename);
							} else {
								version_num = DownloadFileVersion.get(Filename);
							}
							String Query_hit_message = "QUERYHIT%" + msgID + "%" + Integer.toString(currentTTL)
									+ "%" + Filename + "%" + this.My_IP + "%" + this.NumID + "%"
									+ Integer.toString(version_num) + "%" + FileLastModify.get(Filename);

							workSocket(Previous_sender_IP, Integer.parseInt(Previous_sender_PORT), Query_hit_message);
														message(this.NumID + "@Client: Queryhit message is sent <<<");
							
						} else {

							message(this.NumID + "@Client: We dont' have this file " + Filename
									+ " or we don't have the newest<<<");
							message("");
							String Miss_message = "MISS%" + msgID + "%" + Filename + "%" + this.NumID;
							workSocket(Previous_sender_IP, Integer.parseInt(Previous_sender_PORT), Miss_message);
													}
						if (currentTTL > 0) {
							message(
									this.NumID + "@Client: Current TTL is " + Integer.toString(currentTTL) + " <<<");
							message("");
							this.send_request2neighbor(neighbor_IP, Filename, msgID, this.NumID, currentTTL,
									Previous_senderNumID);
						} else {
							message(this.NumID + "@Client: TTL is zero now. No more forwarding!");
							message("");
						}
					} else {
						message(this.NumID + "@Client: This message is already seen before.");
						message("");
					}

				} else if (requestInfo[0].equals("QUERYHIT")) {

					String MessageID = requestInfo[1];
					int currentTTL = Integer.parseInt(requestInfo[2]) - 1;
					String Filename = requestInfo[3];
					String Fetching_IP = requestInfo[4];
					String Fetching_NumID = requestInfo[5];
					String VersionNum = requestInfo[6];
					String LastModify = requestInfo[7];

					int Fetching_PORT = Integer.parseInt(Fetching_NumID) + START_SEARCH_PORT;

					String OwnerOfMessage = MessageID.split("##")[0];

					if (this.NumID.equals(OwnerOfMessage)) {
						// Start to fetch files
						// The first one to fetch, check the local file first !!

						synchronized (this) {

							String log_file_name = DOC_PATH + NumID + "/" + MessageID;
							FileWriter fw = new FileWriter(log_file_name, true);

							fw.write(Fetching_NumID + ":" + LastModify + "\n");
							fw.close();

							String path_ = "./docs/" + NumID + "/downloaded/" + Filename;
							File file = new File(path_);

							if (!file.exists() || FileValid.get(Filename).equals("INVALID")) {
								message(this.NumID + "@Client: " + Fetching_NumID
										+ "@Client, You are the first one to let me download " + Filename
										+ " Let's communicate <<<");
								message("");

								message(
										this.NumID + "@Client: We are creating a new thread to fetch the file <<< ");
								message(" ");

								FileLastModify.put(Filename, LastModify);
								DownloadFileVersion.put(Filename, Integer.parseInt(VersionNum));
								FileValid.put(Filename, "VALID");

								Runnable FiletoReceive = new FileReceiver(Fetching_NumID, Fetching_IP, Filename,
										this.NumID);
								Thread FiletoReceiveThread = new Thread(FiletoReceive);
								FiletoReceiveThread.start();

							} else {

								message(this.NumID + "@Client: " + Fetching_NumID
										+ "@Client, Thanks for helping me. I already has this file " + Filename
										+ " <<<");
								message("");

							}
						}

					} else {
						// Continue to back forward!!!
						message(this.NumID + "@Client: we are receiving from QUERYHIT which "
								+ Fetching_NumID + "@Client has the file " + Filename + " you want <<<");
						message("");

						String previous_IP_PORT = Query_map.get(MessageID);
						String previous_IP = previous_IP_PORT.split(":")[0];
						String previous_PORT = previous_IP_PORT.split(":")[1];
						workSocket(previous_IP, Integer.parseInt(previous_PORT), resp);
					
						int next_hop = Integer.parseInt(previous_PORT) - START_SEARCH_PORT;

						message(this.NumID + "@Client: we are back forwarding this QUERYHIT to "
								+ Integer.toString(next_hop) + "@Client first.");
						message("");

					}

				} else if (requestInfo[0].equals("MISS")) {

					String MessageID = requestInfo[1];
					String Filename = requestInfo[2];
					String Miss_senderNumID = requestInfo[3];

					String OwnerOfMessage = MessageID.split("##")[0];

					if (this.NumID.equals(OwnerOfMessage)) {

						// Destination
						message(this.NumID + "@Client: The peerend " + Miss_senderNumID
								+ "@Client doesn't have the file  " + Filename + " <<<");
						message("");

					} else {
						// Back forward

						message(this.NumID + "@Client: we are receiving from MISS which " + Miss_senderNumID
								+ "@Client doesn't have the file  " + Filename + " <<<");
						message("");

						String previous_IP_PORT = Query_map.get(MessageID);
						String previous_IP = previous_IP_PORT.split(":")[0];
						String previous_PORT = previous_IP_PORT.split(":")[1];

						Socket MyClient;
						MyClient = new Socket(previous_IP, Integer.parseInt(previous_PORT));

						BufferedReader input;
						input = new BufferedReader(new InputStreamReader(MyClient.getInputStream()));
						PrintStream output;
						output = new PrintStream(MyClient.getOutputStream());

						output.println(resp);
						output.flush();
						MyClient.close();
					}

				} else if (requestInfo[0].equals("INVALIDATE")) {

//				String query_message = "INVALIDATE%" + MessageID + "%" + Integer.toString(TTL_UPDATE) + "%" + 
//						FileName + "%" + currentNumID + "%" + this.MasterFileVersion.get(FileName);

					String messageID = requestInfo[1];
					int Current_TTL_UPDATE = Integer.parseInt(requestInfo[2]) - 1;
					String FileName = requestInfo[3];
					String SenderNumID = requestInfo[4];
					int VersionNum = Integer.parseInt(requestInfo[5]);

					String Fetching_IP = this.get_IP();
					String DownloadFileFolderPath = DOC_PATH + NumID + "/downloaded/";

					String MessageID2store = SenderNumID + "#" + messageID;

					if (Peer2SearchQuery.MessageIDInvalidate.contains(MessageID2store)) {

						message(this.NumID + "@Client: We've already seen this Invalidate messages.");
						message("");

					} else {

						MessageIDInvalidate.add(MessageID2store);

						if (DownloadFileVersion.containsKey(FileName)) {

							message(this.NumID + "@Client: We have the file " + FileName);
							message("");

							if (VersionNum > DownloadFileVersion.get(FileName)) {

								FileValid.put(FileName, "INVALID");

								message(this.NumID + "@Client: The file " + FileName
										+ " in this peer is not valid anymore.");
								message("");

							} else {
								message(this.NumID + "@Client: We have the newest file " + FileName);
								message("");
							}

						} else {

							message(this.NumID + "@Client: We don't have " + FileName
									+ " in the downloaded folder. There is no need to update.");
							message("");
						}

						if (Current_TTL_UPDATE > 0) {

							sendInvalidate2neighbor(neighbor_IP, resp);

						} else {

							message(
									this.NumID + "@Client: TTL of INVALIDATE is zero now. No more forwarding!");
							message("");
						}
					}
				} else if (requestInfo[0].equals("PULL")) {

					String file_name_ = requestInfo[1];
					int RemoteVersion = Integer.parseInt(requestInfo[2]);
//				String query_message = "PULL%" + current_filename + "%" + current_fileversion;
					int MasterVersion = MasterFileVersion.get(file_name_);

					if (RemoteVersion < MasterVersion) {

						out.println("OUTDATED");
						out.flush();

					} else {

						out.println("NEW");
						out.flush();
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		private void message(String string) {
			System.out.println(string);
			
		}

		public static ArrayList<String> fileScan(String fp) {
			ArrayList<String> list_files = new ArrayList<String>();
			File[] fileList = new File(fp).listFiles();
			for (int i = 0; i < fileList.length; i++) {
				list_files.add(fileList[i].getName());
			}
			return list_files;
		}

		
		public String get_IP() {

			return "127.0.0.1";
		}

		public void send_request2neighbor(HashMap<String, String> neighbor_IP, String FileName, String MessageID,
				String currentNumID, int currentTTL, String Previous_senderNumID) throws Exception {

			for (String key : neighbor_IP.keySet()) {

				if (key.equals(Previous_senderNumID)) {

					message(
							this.NumID + "@Client: We are not sending the query message back to previous sender <<<");
					message("");

				} else {

					message(this.NumID + "@Client: We are forwarding to " + key + " <<<");
					message("");
					int current_port = Integer.parseInt(key) + START_SEARCH_PORT;
					String current_ip = neighbor_IP.get(key);
					String query_message = "QUERY%" + MessageID + "%" + Integer.toString(currentTTL) + "%" + FileName
							+ "%" + currentNumID;
					workSocket(current_ip, current_port, query_message);
					
				}
			}
		}

		public void sendInvalidate2neighbor(HashMap<String, String> neighbor_IP, String message2send) throws Exception {

			for (String key : neighbor_IP.keySet()) {

				message(this.NumID + "@Client: We are forwarding to " + key + " <<<");
				message("");
				int current_port = Integer.parseInt(key) + START_SEARCH_PORT;
				String current_ip = neighbor_IP.get(key);
				workSocket(current_ip, current_port, message2send);
			
			}
		}
		public static void workSocket(String IP, int port, String query)
				throws UnknownHostException, IOException {
			Socket socket;
			socket = new Socket(IP, (port));
			BufferedReader input;
			input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintStream output;
			output = new PrintStream(socket.getOutputStream());

			output.println(query);
			output.flush();
			socket.close();

		}
	
	}
	//Completed
	class ClientPullUpdate implements Runnable {
		final static int START_SEARCH_PORT = 6410;
		String time_TTR;
		static HashMap<String, String> is_valid;
		static HashMap<String, Integer> file_vrsn;
		ArrayList<String> dwld_list;
		String clientNumber;
		static HashMap<String, String> server_Downlaod;
		ClientPullUpdate(String TTR_Time, String NumID, HashMap<String, String> DownloadedServerMap,
				HashMap<String, Integer> DownloadFileVersion, HashMap<String, String> FileValid) {
			this.clientNumber = NumID;
			this.time_TTR = TTR_Time;
			ClientPullUpdate.file_vrsn = DownloadFileVersion;
			ClientPullUpdate.server_Downlaod = DownloadedServerMap;
			ClientPullUpdate.is_valid = FileValid;			
		}
		
		@Override
		public void run() {
			int wait_time = Integer.parseInt(time_TTR) * 1000;
			String downlaod_path = "./docs/" + clientNumber + "/downloaded/";
			while (true) {
				try {
					dwld_list = fileScan(downlaod_path);
					for (int i = 0; i < dwld_list.size(); i++) {
						String file_name_curr = dwld_list.get(i);
						int port = Integer.parseInt(server_Downlaod.get(file_name_curr))
								+ START_SEARCH_PORT;
						String ipaddress = "127.0.0.1";
						Socket socket;
						socket = new Socket(ipaddress, port);
						BufferedReader bufferReader;
						bufferReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
						PrintStream out;
						out = new PrintStream(socket.getOutputStream());
						String fl_current = Integer.toString(file_vrsn.get(file_name_curr));

						String query = "PULL%" + file_name_curr + "%" + fl_current;
						out.println(query);
						out.flush();
						String readline = bufferReader.readLine();
						if (readline.equals("OUTDATED")) {
							message("----Client"+clientNumber+": The file " + file_name_curr + " is not latest file or it is outdated.");
							message("");
							is_valid.put(file_name_curr, "INVALID");
						} else if (readline.equals("NEW")) {
							message("----Client"+clientNumber+": The file " + file_name_curr + " is latest file or it is updated.");
							message("");
							is_valid.put(file_name_curr, "VALID");
						}
					}
					Thread.sleep(wait_time);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		private void message(String string) {
			System.out.println(string);
			
		}

		public static ArrayList<String> fileScan(String fp) {
			ArrayList<String> list_files = new ArrayList<String>();
			File[] fileList = new File(fp).listFiles();
			for (int i = 0; i < fileList.length; i++) {
				list_files.add(fileList[i].getName());
			}
			return list_files;
		}
	}
	
//Completed
class ClientServer implements Runnable {

	final static int START_SEARCH_PORT = 6410;
	final static int START_FILE_REQ = 6530;
	final static int START_FILE_PORT = 6650;
	int port_number;
	int fileClient;
	String clientName;

	ClientServer(String NumID, String peername) throws IOException {
		this.port_number = Integer.parseInt(NumID) + START_FILE_REQ;
		this.fileClient = Integer.parseInt(NumID) + START_FILE_PORT;
		this.clientName = peername;
	}
	
	@Override
	public void run() {
		try {
			ServerSocket socket_Server = new ServerSocket(port_number);
			ServerSocket server = new ServerSocket(fileClient);
			while (true) {
				message(" ");
				message("----Client"+clientName+": I'm waiting for your retrieving file request.");
				Socket ser_socket = socket_Server.accept();
				Runnable runnable = new FileSender(ser_socket, clientName, server);
				Thread filesenderThread = new Thread(runnable);
				filesenderThread.start();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void message(String message) {
		System.out.println(message);
	}
}
//Completed
	class FileSender implements Runnable {
		private static final boolean TRUE = true;
		Socket req_recieve;
		String PATH;
		ServerSocket file_req;
		String ClientName;

		FileSender(Socket receive_socket, String clientname, ServerSocket file_Req) {

			this.req_recieve = receive_socket;
			this.PATH = "./docs/" + clientname + "/";
			this.file_req = file_Req;
			this.ClientName = clientname;

		}

		public void run() {

			try {

				BufferedReader bufferReader = new BufferedReader(new InputStreamReader(req_recieve.getInputStream()));
				PrintWriter print = new PrintWriter(req_recieve.getOutputStream(), true);
				message(ClientName+"@Client:Please let me know which file you require.");
				message(" ");
				String resp = "";

				while (!(resp.equals("HELLO"))) {

					resp = bufferReader.readLine();
					message(ClientName+"@Client: Get the messages: "+resp);
					message(" ");

					if (resp.equals("HELLO")) {
						print.println("HELLO");
						print.flush();
						message(ClientName+"@Client: Send the messages: " + resp);
						message(" ");
					}

				}

				while (!(resp.equals("CLOSE"))) {
					resp = bufferReader.readLine();
					String[] req_info = resp.split(" ");
					if (req_info[0].equals("RETRIEVE")) {
						Socket file_socket = file_req.accept();
						String fl_name = req_info[1];
						String mstr_folderpath = PATH + "master/";
						ArrayList<String> m_list = fileScan(mstr_folderpath, ClientName);
						String dwnld_path = PATH + "/downloaded/";
						ArrayList<String> downld_list = fileScan(dwnld_path, ClientName);
						String open_fp;
						if (m_list.contains(fl_name)) {
							open_fp = mstr_folderpath + req_info[1];
						} else {
							open_fp = dwnld_path + req_info[1];
						}

						print.println("OK");
						print.flush();
						File file_sent = new File(open_fp);
						synchronized (file_sent) {
							byte[] bfr_byte = new byte[(int) file_sent.length()];
							BufferedInputStream inputFile = new BufferedInputStream(new FileInputStream(file_sent));
							inputFile.read(bfr_byte, 0, bfr_byte.length);
							BufferedOutputStream output_file = new BufferedOutputStream(
									file_socket.getOutputStream());
							output_file.write(bfr_byte, 0, bfr_byte.length);
							output_file.flush();
						}
						message(ClientName+"@Client: The file " + fl_name + " is sent.");
						message(" ");
					}
				}
				message(ClientName+"@Client: Exiting current sending thread.");
				print.println("CLOSE");
				print.flush();
				req_recieve.close();
			} catch (IOException e) {
					e.printStackTrace();
			} finally {
			}
		}
		public void message(String message) {
			System.out.println(message);
		}
		public ArrayList<String> fileScan(String fp, String NumID) {
			ArrayList<String> list_files = new ArrayList<String>();
			File[] fileList = new File(fp).listFiles();
			for (int i = 0; i < fileList.length; i++) {
				list_files.add(fileList[i].getName());
			}
			return list_files;
		}
}

	class FileReceiver implements Runnable {

		final static int STARTING_SEARCHING_PORT = 6410;
		final static int STARTING_FILE_REQUEST_PORT = 6530;
		final static int STARTING_FILE_PORT = 6650;

		int PeerFileSenderPort;
		String PeerFileSenderAdd;
		String FileName;
		final static String FileSize = "999999999";
		String CurrentPeerName;
		String FilePath;
		String SenderNumID;

		FileReceiver(String SenderNumID, String PeerFileSenderAdd, String FileName, String NumID) {
			this.SenderNumID = SenderNumID;
			this.PeerFileSenderPort = Integer.parseInt(SenderNumID) + STARTING_FILE_REQUEST_PORT;
			this.FileName = FileName;
			this.CurrentPeerName = NumID;
			this.PeerFileSenderAdd = PeerFileSenderAdd;
			this.FilePath = "./docs/" + CurrentPeerName + "/downloaded/" + FileName;
		}

		public void run() {

			try {

				int bytesRead;
				int current = 0;

				int PeerFileSenderPort_ForFile = STARTING_FILE_PORT + Integer.parseInt(SenderNumID);

				Socket FileRequestSocket = new Socket(PeerFileSenderAdd, PeerFileSenderPort);
				Socket FileReceiverSocket = new Socket(PeerFileSenderAdd, PeerFileSenderPort_ForFile);

				BufferedReader msgIn = new BufferedReader(new InputStreamReader(FileRequestSocket.getInputStream()));
				PrintWriter msgOut = new PrintWriter(FileRequestSocket.getOutputStream());

				message(CurrentPeerName + "@Client: Preparing to receive file " + FileName + " from " + SenderNumID);
				message(" ");

				msgOut.println("HELLO");
				msgOut.flush();

				String Hello = "RETRIEVE " + FileName;

				msgOut.println(Hello);
				msgOut.flush();

				String hello = msgIn.readLine();

				if (msgIn.readLine().equals("OK")) {

					java.io.InputStream fileIn = FileReceiverSocket.getInputStream();
					PrintWriter fileoutForSender = new PrintWriter(FileReceiverSocket.getOutputStream(), true);

					long startTime = System.currentTimeMillis();

					synchronized (new File(FilePath)) {

						BufferedOutputStream fileOut = new BufferedOutputStream(
								new FileOutputStream(new File(FilePath)));

						byte[] buffer = new byte[Integer.parseInt(FileSize)];

						bytesRead = fileIn.read(buffer, 0, buffer.length);

						message(CurrentPeerName + "@Client: I'm receiving the file " + FileName);
						message("");

						fileOut.write(buffer, 0, bytesRead);
						fileOut.flush();

					}

					message(CurrentPeerName + "@Client: File " + FilePath + " downloaded (" + bytesRead
							+ " bytes read)");
					message("");

					long stopTime = System.currentTimeMillis();

					message(CurrentPeerName + "@Client: transfer speed: "
							+ (double) bytesRead / 1000 / (stopTime - startTime) + " Mb/sec.");
					message("");

					msgOut.println("CLOSE");
					msgOut.flush();

					while (true) {
						if (msgIn.readLine().equals("CLOSE")) {
							FileRequestSocket.close();
							FileReceiverSocket.close();
							break;
						} else {
							continue;
						}
					}

				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		private void message(String string) {
			System.out.println(string);
			
		}

	

	}

class UpdateThread implements Runnable{
	final static int TTL = 3;
	final static int START_SEARCH_PORT = 6410;
	
	String time_ttr; 
	String client_ID;
	HashMap<String, String> isValid;
	HashMap<String, String> nbr_IP;

	UpdateThread(String timr_ttr, String client_ID, HashMap<String, String> isVAlid, HashMap<String, String> nbrIP){
		this.time_ttr = timr_ttr;
		this.client_ID =client_ID;
		this.isValid = isVAlid;
		this.nbr_IP =nbrIP;
	}
	
	@Override
	public void run() {
		int a = 1000;
		int time = Integer.parseInt(time_ttr) * a;
		int j = 0;
			try {			
				for (String key : isValid.keySet()){			
					if(isValid.get(key).equals("INVALID")){
						j += 1;
						String MessageID = client_ID + "##" + Integer.toString(j) + "_UPDATE";
						sendReqNbr(nbr_IP, key,MessageID, client_ID);			
					}
				}				
				Thread.sleep(time);
			} catch (Exception e) {
				e.printStackTrace();
			}
		
	}
	
	
	public static void sendReqNbr(HashMap<String, String> nbrIP, String fl_nm,
			String msg_ID, String curr_ID) throws Exception{				
		for (String key : nbrIP.keySet()) {
			int current_port = Integer.parseInt(key) + START_SEARCH_PORT;
			String current_ip = nbrIP.get(key);
			String message = "QUERY%"+msg_ID+"%"+Integer.toString(TTL) + "%" + fl_nm + "%" + curr_ID;
			workSocket(current_ip, current_port, message);
			
			
		}
	}
	public static void workSocket(String IP, int port, String query)
			throws UnknownHostException, IOException {
		Socket socket;
		socket = new Socket(IP, (port));
		BufferedReader input;
		input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		PrintStream output;
		output = new PrintStream(socket.getOutputStream());

		output.println(query);
		output.flush();
		socket.close();

	}

	
}

