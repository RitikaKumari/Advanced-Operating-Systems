import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class Peer {
	
	
	public static void initFiles(String pr_name, int num) throws IOException {
		int ran_number = num;
		message(pr_name + "---->: Your Random Number is:  " + ran_number);
		message(" ");
		OutputStream outStream = null;
		InputStream inStream = null;
		String client_folder = "./" + pr_name+ "/" ;
		File  x = new File("./" + pr_name+ "/");
		if(x.exists()){
			String[]str = x.list();
			for(String s: str){
			    File currentFile = new File(x.getPath(),s);
			    currentFile.delete();
			}
		}else{
			x.mkdir();
		}
		
		File[] file_list = new File("./" + ran_number + "/").listFiles();
		for (int i = 0; i < file_list.length; i++) {
						
			File file = new File(pr_name + "/" + file_list[i].getName());
			inStream = new FileInputStream(file_list[i]);
			outStream = new FileOutputStream(file);

			byte[] buffer = new byte[1024];
			int bytes_read;
			while ((bytes_read = inStream.read(buffer)) > 0) {
				outStream.write(buffer, 0, bytes_read);
			}

		}

	}
	
	public static void main(String[] args) throws Exception{
		message("Ypu are at the Client End");
		message(" ");
		BufferedReader bfrio = new BufferedReader(new InputStreamReader(System.in));
		message("Enter the IP of the server");
		String server_ip = bfrio.readLine();
		String port = "6666";
		message("Please enter the Port Number:   ");
		String port_number = bfrio.readLine();
		message("Please enter the Client Name:  ");
		String str_name = bfrio.readLine();
		message("Please choose a number from 1,2,3,4 (It will create file): ");
		String random_number = bfrio.readLine();
		
		String FileFolderPath = "./" + str_name + "/";
		initFiles(str_name, Integer.parseInt(random_number));
		String client_IP = get_ip();
		Socket MyClient = new Socket(server_ip, Integer.parseInt(port));
		BufferedReader bfrinput;
		bfrinput = new BufferedReader(new InputStreamReader(MyClient.getInputStream()));		
		PrintStream printoutput;
		printoutput = new PrintStream(MyClient.getOutputStream());
        Runnable clientrunnable = new ClientServer(Integer.parseInt(port_number), str_name);
        Thread peerserverThread = new Thread(clientrunnable);
        peerserverThread.start();
		printoutput.println("Hello");
		printoutput.flush();
		if(bfrinput.readLine().equals("Hello")){
			message(str_name + "---->: " + "Connected to Index Server");
			message(" ");
			String command2 = str_name + " " + client_IP + " " + port_number;
			printoutput.println(command2);
			printoutput.flush();
			new ScanFile(str_name, printoutput).start();
			
		}
		message(str_name + "---->: " + "Wait for a while........");
		message(" ");
		Thread.sleep(3000);
		message(str_name + "---->: " + "Please type <LIST> and <SEARCH> command for listing and searching the document.");
		message(" ");
		message(str_name + "---->: example: SEARCH doc_1.txt");
		message(" ");
		String command1 = ""; 
		while(!command1.equals("QUIT")){
			command1 = bfrio.readLine();
			String [] strcmd = command1.split(" ");
			if (strcmd[0].equals("LIST")){
				
				String sendCommand = "LIST";
				printoutput.println(sendCommand);
				printoutput.flush();
				
				if(bfrinput.readLine().equals("LIST")){
					message(str_name + "---->: " + "List on Index Server: ");
					message(" ");
					String msglist = "";
					while(!msglist.equals("OVER")){
						msglist = bfrinput.readLine();
						message(msglist);
					}
					message(str_name + "---->: " + "Please type <LIST> and <SEARCH> command for listing and searching the document.");
					message(" ");
				}						
			}else if(strcmd[0].equals("SEARCH")){
				message(str_name + "---->: " + "Sending the SEARCH request to index server");
				message(" ");
				String file_name = strcmd[1];
				ArrayList <String> file_Temp = new ArrayList <String>();			
				File[] list_temp = new File(FileFolderPath).listFiles();
				for(int i=0;i<list_temp.length;i++){
					String temp_file_string = list_temp[i].getName();
					file_Temp.add(temp_file_string);			
				}
				if(file_Temp.contains(file_name)){
					message(str_name + "---->: File already exists" );
					message(" ");
					message(str_name + "---->: LIST to view all files.");
					message(" ");
					continue;
				}
				printoutput.println(command1);
				printoutput.flush();	
				String srch_response = bfrinput.readLine();
				String [] srch_seg = srch_response.split(" ");
				if(srch_seg[0].equals("RESULTS")){
					message(str_name + "---->: " + "CIServer assigned the Peer: " + srch_response.split(" ")[1]);
					message(" ");
					message(str_name + "---->: " + "Please wait... ");
					message(" ");
					
					String info_resp = bfrinput.readLine();
					message(str_name + "---->: " + info_resp);
					
					String [] info_report_seg = info_resp.split(" ");
					String sender = info_report_seg[2];
					String senderaddress = info_report_seg[1];
									
					message(str_name + "---->: Creating new thread. Input LIST or to SEARCH <filename> to search");
					message(" ");
					Runnable file_receive = new ClientFileReceiver(Integer.parseInt(sender), senderaddress, file_name, str_name);
					Thread receiveThread = new Thread(file_receive);
					receiveThread.start();
					
				}else if(srch_seg[0].equals("SORRY")){
					
					message(str_name + "---->: No Such File Found ");
					message(" ");
					
				}

			}

			
			else{
				message(str_name + "---->: Please check the command you have entered");
				message(" ");
			}
		}					
	}
	
	public static void message(String message) {
		System.out.println(message);
	}
	
	public static String get_ip(){

		InetAddress ipaddress;
		
		try {
			
			ipaddress = InetAddress.getLocalHost();
			return ipaddress.getHostAddress();		
			
		} catch (Exception e) {
			e.printStackTrace();
			return "localhost";
		}	
	}

}


class ClientServer implements Runnable{
	
	int port_number;
	int port_file;
	String clientName;
	ClientServer(int portnm, String prname) throws IOException{
		
		this.port_number = portnm;
		this.port_file = portnm + 1;
		this.clientName = prname;
			
	}
	
	@Override
	public void run() {
		try {
			ServerSocket list_req = new ServerSocket(port_number);
			ServerSocket file_request = new ServerSocket(port_file);
			while (true) {
				message(" ");
				message(clientName + "---->: Waiting for the Request file");
				message(" ");
				Socket serviceSocket = list_req.accept();	
				Runnable filesender = new SendFile(serviceSocket, clientName, file_request);
				Thread filesenderThread = new Thread(filesender);
				filesenderThread.start();		
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void message(String message) {
		System.out.println(message);
	}
}

class SendFile implements Runnable {
	
	private static final boolean TRUE = true;
	Socket receive_req;
	String folderpath;
	ServerSocket reqFile;
	String clientName;
	
	SendFile(Socket receive_socket, String clientName, ServerSocket reqFile){
		
		this.receive_req = receive_socket;
		this.folderpath = "./" + clientName + "/";
		this.reqFile = reqFile;
		this.clientName = clientName;
		
	}
	
	public void run() {
		
        try {
        	
			BufferedReader bfrin = new BufferedReader(new InputStreamReader(receive_req.getInputStream()));
			PrintWriter bfrout = new PrintWriter(receive_req.getOutputStream(), true);
			message(clientName + "---->: Let me know which file you want.");
			message(" ");
			String response = "";
			
			while(!(response.equals("HELLO"))){
				
				response = bfrin.readLine();
				message(clientName + "---->: Get the messages: " + response);
				message(" ");
	
				if (response.equals("HELLO")){			
					bfrout.println("HELLO");
					bfrout.flush();
					message(clientName + "---->: Send the messages: " + response);
					message(" ");
				}
				
			}
			
			while(!(response.equals("CLOSE"))){
				
				response = bfrin.readLine();
				String[] requestInfo = response.split(" ");
							
				if(requestInfo[0].equals("RETRIEVE")){
					
					Socket FileReques_Socket = reqFile.accept();
					
					String filename = requestInfo[1];
					String OpenFilePath = folderpath + requestInfo[1];
					
					bfrout.println("OK");
					bfrout.flush();
					
					File FileToBesent = new File(OpenFilePath);
					
					synchronized(FileToBesent){
						
						byte[] bufferbes = new byte[(int)FileToBesent.length()];
						
						BufferedInputStream fileIn = new BufferedInputStream(new FileInputStream(FileToBesent));
						fileIn.read(bufferbes, 0, bufferbes.length);
						
						BufferedOutputStream fileOut = new BufferedOutputStream(FileReques_Socket.getOutputStream());
												
						fileOut.write(bufferbes, 0, bufferbes.length);
						fileOut.flush();
						
					}

					message(clientName + "---->: File " + filename + "  sent.");
					message(" ");
									
				}
			}
			
			message(clientName + "---->: Exiting from current thread");
			message(" ");
			
			bfrout.println("CLOSE");
			bfrout.flush();
					
			receive_req.close();
						
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//printStackTrace();
		} finally{

		}
        
	}
	
	public void message(String message) {
		System.out.println(message);
	}
	
}


class ClientFileReceiver implements Runnable {
	
	
	String clientFileAddress,clientFileName;
	final static String FileSize = "999999999";
	int clientFilePort;
	String currentClient;
	String currentFilePath;
	
	
	ClientFileReceiver(int PeerFileSenderPort, String PeerFileSenderAdd, String FileName, String CurrentPeerName){
		this.clientFilePort = PeerFileSenderPort;
		this.clientFileName =FileName;
		this.currentClient = CurrentPeerName;
		this.clientFileAddress = PeerFileSenderAdd;
		this.currentFilePath = "./" + CurrentPeerName + "/" + FileName;	
	}
	
	public void run() {
		try {
			int byte_read;
			int current_run = 0;
			int currentfileport = clientFilePort + 1;
			Socket socketFileRequest = new Socket(clientFileAddress, clientFilePort);
			Socket socketFileRecevier = new Socket(clientFileAddress, currentfileport);
            BufferedReader msgIn = new BufferedReader(new InputStreamReader(socketFileRequest.getInputStream()));
            PrintWriter write = new PrintWriter(socketFileRequest.getOutputStream());
			message("Preparing file to receive" + clientFileName + " from "+ clientFileAddress);
			message(" ");
            write.println("HELLO");
            write.flush();
			String Hello = "RETRIEVE " + clientFileName;
			write.println(Hello);
			write.flush();
			String msgHello = msgIn.readLine();
			if(msgIn.readLine().equals("OK")){
					InputStream inputStream = socketFileRecevier.getInputStream();
					PrintWriter fileoutForSender = new PrintWriter(socketFileRecevier.getOutputStream(), true);
					synchronized(new File(currentFilePath)){
						BufferedOutputStream fileOut = new BufferedOutputStream(new FileOutputStream(new File(currentFilePath)));
						byte[] bufferread = new byte[Integer.parseInt(FileSize)];
						byte_read = inputStream.read(bufferread,0,bufferread.length);
						message(currentClient + "---->: I'm receiving the file "+ clientFileName);
						fileOut.write(bufferread, 0 , byte_read);
						fileOut.flush();
					}
					
					message(currentClient + "---->: File " + currentFilePath + " downloaded (" + current_run + " bytes read)");
					
					write.println("CLOSE");
					write.flush();
					
					while(true){
						if(msgIn.readLine().equals("CLOSE")){
							socketFileRequest.close();
							socketFileRecevier.close();
							break;
						}else{
							continue;
						}
					}
				}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void message(String message) {
		System.out.println(message);
	}
}

class ScanFile extends Thread {
	
	String clientName;
	String file_path;
	ArrayList<String> listFile = new ArrayList<String>();
	PrintStream outStream;
	
	ScanFile(String client_nm, PrintStream output) throws IOException{
		
		this.outStream = output;
		this.clientName = client_nm;
		this.file_path = "./" + clientName + "/";
		File[] list = new File(file_path).listFiles();
		
		for(int i=0; i<list.length; i++){
			message(clientName + "--> Find the new file " + list[i].getName());
			this.listFile.add(list[i].getName());
		}
		
		for(int i=0; i<listFile.size(); i++){
			
			this.indexAddition(listFile.get(i));
		}
		
	}

	public void message(String message) {
		System.out.println(message);
	}

	
	public void indexAddition(String strfile) throws IOException{
		String add_req = "ADD" + " " + clientName + " " +strfile;
		outStream.println(add_req);
		outStream.flush();
	}
	
	public void removalIndex(String strfile) throws IOException{
		String single_request = "DELETE" + " " + clientName + " " +strfile;
		outStream.println(single_request);
		outStream.flush();
	}
	
	public HashMap <String, ArrayList<String>> Routine_Scan(){
		File[] list_temp = new File(file_path).listFiles();
		HashMap <String, ArrayList<String>> m = new HashMap<String, ArrayList<String>>();
		ArrayList<String> fileListTemp = new ArrayList<String>();
		ArrayList<String> addindex = new ArrayList<String>();  
		ArrayList<String> deleteindex = new ArrayList<String>();

		for(int i=0;i<list_temp.length;i++){
			String tempString = list_temp[i].getName();
			fileListTemp.add(tempString);

			if(!listFile.contains(tempString)){
				message(clientName + "---->: Find the new file " + tempString);
				addindex.add(tempString);			
			}
		}
		for(int j=0;j<listFile.size();j++){
			if(!fileListTemp.contains(listFile.get(j))){
				message(clientName + "---->: Find the delete file " + listFile.get(j));
				deleteindex.add(listFile.get(j));
			}
		}
		m.put("ADD", addindex);
		m.put("DELETE", deleteindex);
		return m;
		
	}
	
	
	public void run(){
		while(true){
			try {
				HashMap <String, ArrayList<String>> temp_m = new HashMap<String, ArrayList<String>>();
				temp_m = Routine_Scan();
				ArrayList<String> addindex = temp_m.get("ADD");  
				ArrayList<String> deleteindex = temp_m.get("DELETE");;
				Thread.sleep(10000);
				for(int i=0; i<deleteindex.size();i++){				
					listFile.remove(deleteindex.get(i));
					removalIndex(deleteindex.get(i));
				}
				for(int i=0; i<addindex.size();i++){					
					listFile.add(addindex.get(i));	
					indexAddition(addindex.get(i));
				}
									
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
	}	
}
