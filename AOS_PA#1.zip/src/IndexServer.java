import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

public class IndexServer {
	
	static int Portnumber = 6666;
	final int MaximumPeer = 10;
	final static String IndexFileName = "Mapping.txt";
	/**
	 * Main function
	 */
	public static void main(String[] args) throws Exception  {
		// TODO Auto-generated method stub
		int clientNumber = 1;
		
		String ip = get_ip();
		
		log("This is Index Server end. <<< ");
		log(String.format("The port number is %s." , Portnumber) + " <<<");
		log(String.format("The IP address is %s." , ip));
		log("Please provide the upon information to the clients ends (peers). <<<");
		log(" ");
					
		ServerSocket MyService = new ServerSocket(Portnumber);
		HashMap <String, ArrayList<String>> Mapping = new HashMap <String, ArrayList<String>>();
	    HashMap <String, String> Mapping_IP = new HashMap <String, String>();
	    HashMap <String, String> Mapping_PORT = new HashMap <String, String>();
		
		while(true){
			
			Socket serviceSocket = MyService.accept();

			new IndexServerThread(serviceSocket, Mapping, Mapping_IP, Mapping_PORT).start();

		}
	}
	
	/**
	 * Get the current IP address
	 * @return: IP address as string
	 */
	public static String get_ip(){

		InetAddress ip;
		
		try {
			ip = InetAddress.getLocalHost();
			return ip.getHostAddress();		
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}	
	}
	
	public static void log(String message) {
		System.out.println(message);
	}
}



class IndexServerThread extends Thread{

    private Socket socket;
    static HashMap <String, ArrayList<String>> Mapping;
    static HashMap <String, String> Mapping_IP;
    static HashMap <String, String> Mapping_PORT;
    Boolean Initial = false;
    
    String ClientSocketIP;
    String ClientSocketPortNumber;
    
    public IndexServerThread(Socket socket, HashMap<String, ArrayList<String>> Mapping, HashMap <String, String> Mapping_IP, HashMap <String, String> Mapping_PORT) {
    	
        this.socket = socket;
        this.Mapping = Mapping;
        this.Mapping_IP = Mapping_IP;
        this.Mapping_PORT = Mapping_PORT;
        log("From IndexServer : New connection with client# " + " at " + socket + " <<<");
        Mapping = new HashMap <String, ArrayList<String>>();
        Mapping_IP = new HashMap <String, String>();
        Mapping_PORT = new HashMap <String, String>();
        
    }
    
    public IndexServerThread(Socket socket) {
    	
        this.socket = socket;
        log("From IndexServer : New connection with client# " + " at " + socket + " <<<");
        Mapping = new HashMap <String, ArrayList<String>>();
        Mapping_IP = new HashMap <String, String>();
        Mapping_PORT = new HashMap <String, String>();
        
    }
    
    public void PrintHashMap(){
    	
    	log("Here is the current indexing map.");
    	log(" ");
    	for (String key : this.Mapping.keySet()) {
    		log("	"+key + " ---> " + Mapping.get(key));
    	}	 	
    	log(" ");
    }
    
    public void registry(String massages){
    	
    	String [] command = massages.split(" ");
    	String PeerName = command[1];
    	String Filename = command[2];
    	    	
    	if (Mapping.containsKey(Filename)){
    		
    		Mapping.get(Filename).add(PeerName);
    		
    	}else{
    		ArrayList<String> initial_list = new ArrayList<String>();
    		initial_list.add(PeerName);

    		Mapping.put(Filename, initial_list);

    	}
    	
    	log("From IndexServer : Receive indexing " + Filename + " from " + PeerName + " <<<");
    	log(" ");
    	   	
    }
	
    public void delete(String messages){
    	 	
    	String [] command = messages.split(" ");
    	String PeerName = command[1];
    	String Filename = command[2];
    	
    	Mapping.get(Filename).remove(PeerName);
    	ArrayList<String> temp_ArrayList = Mapping.get(Filename);
    	log("From IndexServer : Receive deleting " + Filename + " from " + PeerName + " <<<");
    	log(" ");
    	
    	if (temp_ArrayList.isEmpty()){
    		Mapping.remove(Filename);
    		log("From IndexServer : Also delete the key with " + Filename + " <<<");
    	}
    	

    	
    	
   	   	
    }
    
    public ArrayList<String> ListFiles(){
    	
    	ArrayList<String> results = new ArrayList<String>();
    	for (String key : this.Mapping.keySet()) {
    		String temp = ("	"+key + " ---> " + Mapping.get(key));
    		results.add(temp);
    	}
    	
    	return results;
    }
    
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try {
						
			BufferedReader input;
			input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			
			PrintStream output;
			output = new PrintStream(socket.getOutputStream());
			
			output.println("Hello");
			output.flush();
			
			String ACTION = "";
			
			String massages = input.readLine();
			
			//Format should be "PeerName IP PortNumber" 
			if(massages.equals("Hello")){
				
				massages = input.readLine();
				String [] SecondCommand = massages.split(" ");
				String temp_peer_name = SecondCommand[0];
			    ClientSocketIP = SecondCommand[1];
			    ClientSocketPortNumber = SecondCommand[2];
			    Mapping_IP.put(temp_peer_name, ClientSocketIP);
			    Mapping_PORT.put(temp_peer_name, ClientSocketPortNumber);		    
			}

			while (!massages.equals("QUIT")) {
				
				
				massages = input.readLine();
				String [] command = massages.split(" ");
				
				// log("From IndexServer : Receive messages: " + massages);
				// log(" ");
				
				if (command[0].equals("ADD")) {			
					registry(massages);
					log("From IndexServer : After adding, ");
					PrintHashMap();
					
				}else if(command[0].equals("DELETE")){
					delete(massages);
					log("From IndexServer : After deleting, ");			
					PrintHashMap();
					
				}else if(command[0].equals("LIST")){
					
					ArrayList<String>list_result = ListFiles();
					output.println("LIST");
					output.flush();
					
					for (int i=0;i<list_result.size();i++){
						String OutToFlush = list_result.get(i);
						output.println(OutToFlush);
						output.flush();
					}
					
					output.println("OVER");
					output.flush();
					
				}else if(command[0].equals("SEARCH")){
					
					String filename = command[1];
					log("From IndexServer : The search for " + filename);
					log(" ");
					log("From IndexServer : Sending the list of candidate");
					log(" ");
					
					
					// Test/////////////////////
					
					
					if (!Mapping.containsKey(filename)){
						output.println("SORRY");
						output.flush();
						
					}else {
						
						String listString = "RESULTS ";
						
						String candidate = Mapping.get(filename).get(0);
						
						listString = listString + candidate;
						output.println(listString);
						output.flush();
						
						String target_ip = Mapping_IP.get(candidate);
						String target_port = Mapping_PORT.get(candidate);
						String candidate_infor = "PeerInfor: " + target_ip + " " +target_port;
						
						output.println(candidate_infor);
						output.flush();
						
					}
				}else if(command[0].equals("THANKS")){
					
					log("From IndexServer : Finish searching. Let me know if you need other Infors.");
					log(" ");
					
				}							
			}
        	
        	if (massages.equals("QUIT")){
    			output.close();    
    			input.close();	 
        		socket.close();  		
        	}
     
        	
        } catch (IOException e) {
            log("Error handling client# " + ": " + e);
        } finally {
            log("Connection with client# at " + socket + " closed");
        }
	}
	
    private void log(String message) {
        System.out.println(message);
    }
    	
}
