	import java.io.BufferedInputStream;
	import java.io.BufferedOutputStream;
	import java.io.BufferedReader;
	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.FileReader;
	import java.io.IOException;
	import java.io.InputStreamReader;
	import java.io.PrintStream;
	import java.io.PrintWriter;
	import java.net.InetAddress;
	import java.net.ServerSocket;
	import java.net.Socket;
	import java.net.UnknownHostException;
	import java.nio.file.Files;
	import java.nio.file.Paths;
	import java.nio.file.StandardOpenOption;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.HashMap;
	
	public class client {
	
		static String configPath = "./config/";
		final static String docPath = "./docs/";
		final static int START_SEARCH_POINT = 6410;
		final static int START_FILEREQ_PORT = 6530;
		final static int START_FILE_PORT = 6650;
		final static int TTL = 3;
		final static String IP_file = "./config/ip.txt";
			public static void main(String... args) throws Exception {
			if (args.length == 0) {
				configPath = "./config/config1.txt";
				} else {
				configPath += args[0];
			}
			ArrayList<String> nbrList = new ArrayList<String>();
			ArrayList<String> fileList = new ArrayList<String>();
			HashMap<String, ArrayList<String>> mapConfig = read_config(configPath);
			String IP_address = getIPAddress();
			String filePath;
			int Num_nodes = mapConfig.size();
			HashMap<String, String> nbrIP = new HashMap<String, String>();
	
			BufferedReader bufferInput = new BufferedReader(new InputStreamReader(System.in));
			message("---New Window Client End---");
			message("---Total Clients in the config are " + Integer.toString(Num_nodes) + "---");
			
			message("---Enter the client sequece which starts from 1--- ");
			message("");
			String num = bufferInput.readLine();
			int portNum = START_SEARCH_POINT + Integer.parseInt(num);
			nbrList = mapConfig.get(num);
			filePath = docPath + num + "/";
			fileList = fileScanning(filePath, num);
			writeIPaddress(IP_file, num, IP_address);
			int time = 3000;
			Thread.sleep(time);
			message("------Client"+num+":Type 'YES' once all the Peers are Started------");
			message("------Client"+num+": You need to start" + Integer.toString(Num_nodes) + " Peers in config---");
			message("");
			String commandEntered = bufferInput.readLine();
			while (!commandEntered.equals("YES")) {
	
				message("------Client"+num+":Type 'YES' once all the Peers are Started------");
				message("------Client"+num+": You need to start" + Integer.toString(Num_nodes) + " Peers in config---");
				message("");
				commandEntered = bufferInput.readLine();
			}
	
			nbrIP = nbrIP(nbrList, IP_file);
	
			Runnable clientSearchReceiver = new ClientSearchServer(portNum, num, fileList, nbrIP);
			Thread clientSearchThread = new Thread(clientSearchReceiver);
			clientSearchThread.start();
	
			Runnable runnablePeerServer = new PeerServer(num, num);
			Thread clientServerThread = new Thread(runnablePeerServer);
			clientServerThread.start();
	
			for (String k : nbrIP.keySet()) {
				message("---Client"+num+": You have neighbors :" + k + " with IP: " + nbrIP.get(k));
				message("");
			}
	
			incorrectMethod(num);
			String rdlineCommand = bufferInput.readLine();
			int j = 0;
			while (true) {
				if (!rdlineCommand.split(" ")[0].equals("SEARCH")) {
					incorrectMethod(num);
				} else {
	
					String filename = rdlineCommand.split(" ")[1];
					fileList = fileScanning(filePath, num);
	
					if (fileList.contains(filename)) {
						message("");
						message("---Client"+num+": You already have this file ---");
						incorrectMethod(num);
						message("");
						rdlineCommand = bufferInput.readLine();
						continue;
					}
	
					String msg_ID = num + "##" + Integer.toString(j);
					j++;
					message("---Client"+num+": Requesting neighbour for file");
					message("");
					requestNeighbou(nbrIP, filename, msg_ID, num);
				}
				Thread.sleep(2000);
				incorrectMethod(num);
				rdlineCommand = bufferInput.readLine();
	
			}
	
		}
	
		public static void incorrectMethod(String num) {
			message("---Client " + num + "---- : Use command 'SEARCH FILENAME' to search file in system---");
			message("---Client " + num + "---- : The files are from doc_1.txt - doc_30.txt------");
			message("");
		}
	
		public static void requestNeighbou(HashMap<String, String> nbrIP, String file, String msgID, String currentID)
				throws Exception {
			for (String key : nbrIP.keySet()) {
				int current_port = Integer.parseInt(key) + START_SEARCH_POINT;
				String current_ip = nbrIP.get(key);
				Socket socket = new Socket(current_ip, current_port);
				BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				PrintStream out = new PrintStream(socket.getOutputStream());
				String qryStr = "QUERY%" + msgID + "%" + Integer.toString(TTL) + "%" + file + "%" + currentID;
				out.println(qryStr);
				out.flush();
			}
		}
	
		public static String getIPAddress() {
			InetAddress ipadrs;
			try {
				ipadrs = InetAddress.getLocalHost();
				return ipadrs.getHostAddress();
	
			} catch (Exception ex) {
				ex.printStackTrace();
				return "localhost";
			}
		}
		public static void writeIPaddress(String path, String num, String IP) throws Exception {
			File file = new File(path);
			synchronized (file) {
				if (!file.exists() && !file.isDirectory()) {
					file.createNewFile();
				}
				message(num + "---Client: Wait.. IP is being written to the config file---");
				message("");
				String txt = num + ":" + IP + "\n";
				Files.write(Paths.get(path), txt.getBytes(), StandardOpenOption.APPEND);
			}
		}
		public static HashMap<String, String> nbrIP(ArrayList<String> nbrList, String ipFile) {
			HashMap<String, String> map = new HashMap<String, String>();
			try {
				File file = new File(ipFile);
				synchronized (file) {
					String line;
					FileReader flReader = new FileReader(file);
					BufferedReader bfdReader = new BufferedReader(flReader);
	
					while ((line = bfdReader.readLine()) != null) {
						String[] lnlst = line.split(":");
						String keyName = lnlst[0];
						String keyIP = lnlst[1];
						if (nbrList.contains(keyName)) {
							map.put(keyName, keyIP);
						}
					}
					flReader.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return map;
		}
	
		public static void createObject(File f, String str) {
			f = new File(str);
		}
	
		public static void readingDetail() {
			message("");
			message("Reading the Configuration file to observe the details of Neighbouring Peer");
			message("");
		}
	
		public static void dolisting(String line, HashMap<String, ArrayList<String>> map) {
	
			String[] list_Line = line.split(":");
			String keyName = list_Line[0];
			String values = list_Line[1];
			String[] neighbor_list = values.split(",");
			ArrayList<String> arrayList = new ArrayList<String>(Arrays.asList(neighbor_list));
			map.put(keyName, arrayList);
	
		}
	
		public static HashMap<String, ArrayList<String>> read_config(String ConfigFile) {
			readingDetail();
			HashMap<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();
			try {
				File fl = new File(ConfigFile);
				synchronized (fl) {
					FileReader file_reader = new FileReader(fl);
					BufferedReader bufferedReader = new BufferedReader(file_reader);
					String line;
					while ((line = bufferedReader.readLine()) != null) {
						dolisting(line, map);
					}
					file_reader.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return map;
		}
	
		public static void message(String msg) {
			System.out.println(msg);
		}
	
		/**
		 * This function scans that file if it is in the client(Peer) folder. Two
		 * parameter are passed in the function path and numID and the function returns
		 * an ArrayList having the all the names of the file.
		 */
		public static ArrayList<String> fileScanning(String path, String numID) {
			ArrayList<String> flList = new ArrayList<String>();
			File[] lst = new File(path).listFiles();
			for (int j = 0; j < lst.length; j++) {
				flList.add(lst[j].getName());
			}
			return flList;
		}
	
	}
	
	/***
	 * Class of Query Client Server
	 * 
	 * @author Kumar
	 *
	 */
	class ClientSearchServer implements Runnable {
	
		int portNumber;
		ArrayList<String> query;
		ArrayList<String> file;
		String numID;
		HashMap<String, String> nbrIP;
	
		ClientSearchServer(int portnumber, String NumID, ArrayList<String> FileList, HashMap<String, String> neighbor_IP) {
			this.numID = NumID;
			this.file = FileList;
			this.nbrIP = neighbor_IP;
			this.portNumber = portnumber;
		}
	
		@Override
		public void run() {
			try {
	
				ServerSocket lstrnReq = new ServerSocket(portNumber);
				message("---Client " + numID + ": I'm waiting for your searching query request.");
				message(" ");
				HashMap<String, String> map = new HashMap<String, String>();
				HashMap<String, Integer> queryMap = new HashMap<String, Integer>();
	
				while (true) {
	
					Socket socket = lstrnReq.accept();
					Runnable query = new ClientSearchQuery(socket, numID, file, nbrIP, map, queryMap);
					Thread clientThread = new Thread(query);
					clientThread.start();
				}
	
			} catch (Exception e) {
				e.printStackTrace();
			}
	
		}
	
		public void message(String message) {
			System.out.println(message);
		}
	
	}
	
	/***
	 * Class of Query Peer thread
	 * 
	 * @author Kumar
	 *
	 */
	class ClientSearchQuery implements Runnable {
	
		Socket socket;
		String numID;
		ArrayList<String> file_List;
		HashMap<String, String> nbrIP;
		static HashMap<String, String> map;
		static HashMap<String, Integer> queryMAP;
	
		final static int START_SEARCH_PORT = 6410;
		final static int START_SEARCH_REQ = 6530;
		final static int START_PORT = 6650;
		final static String DOCPATH = "./docs/";
	
		String myIP;
		String myPort;
	
		ClientSearchQuery(Socket QuerySocket, String NumID, ArrayList<String> FileList, HashMap<String, String> neighbor_IP,
				HashMap<String, String> Query_map, HashMap<String, Integer> Queryhit_map) {
	
			this.nbrIP = neighbor_IP;
			this.socket = QuerySocket;
			this.numID = NumID;
			this.myIP = this.get_IP();
			this.map = Query_map;
			this.queryMAP = Queryhit_map;
			this.file_List = FileList;
		}
	
		@Override
		public void run() {
			try {
				BufferedReader bufferReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				PrintWriter print = new PrintWriter(socket.getOutputStream(), true);
				String resp = "";
				String remoteIP = socket.getRemoteSocketAddress().toString();
				resp = bufferReader.readLine();
				String[] request_Info = resp.split("%");
	
				if (request_Info[0].equals("QUERY")) {
	
					String msg = request_Info[1];
					int a = Integer.parseInt(request_Info[2]);
					int currTTL = a - 1;
					String fl_Name = request_Info[3];
					String sendersNumberID = request_Info[4];
					String prevs_NumberID = nbrIP.get(sendersNumberID);
					String prevs_IP = Integer.toString(Integer.parseInt(sendersNumberID) + START_SEARCH_PORT);
	
					String senderPort = prevs_NumberID + ":" + prevs_IP;
					if (!map.containsKey(msg)) {
	
						map.put(msg, senderPort);
						String pathTemp = DOCPATH + this.numID + "/";
						file_List = scan_files(pathTemp);
	
						if (file_List.contains(fl_Name)) {
	
							message("---Client" + this.numID + ": has this file" + fl_Name + "----");
							message("---Client" + this.numID + ": Sendig the hits back----");
							message("");
	
							String querymesssage = "QUERYHIT%" + msg + "%" + Integer.toString(currTTL) + "%" + fl_Name + "%"
									+ this.myIP + "%" + this.numID;
	
							Socket socket;
							int x = Integer.parseInt(prevs_IP);
							socket = new Socket(prevs_NumberID, x);
	
							BufferedReader bfrReader;
							bfrReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
							PrintStream out = new PrintStream(socket.getOutputStream());
							out.println(querymesssage);
							out.flush();
	
							message(this.numID + "---Client:Message sent");
							socket.close();
	
						} else {
	
							message("---Client" + this.numID + " dont have " + fl_Name + " <<<");
							message("Please try some other file");
							String Miss_message = "MISS%" + msg + "%" + fl_Name + "%" + this.numID;
							int ab = Integer.parseInt(prevs_IP);
							workSocket(prevs_NumberID, ab, Miss_message);
							
						}
	
						if (currTTL > 0) {
							message("---Client" + this.numID + ": Current TTL is " + Integer.toString(currTTL) + "----");
							message("");
							this.sendReqNbr(nbrIP, fl_Name, msg, this.numID, currTTL, sendersNumberID);
						} else {
							message(this.numID + "---Client: TTL is zero now. No more forwarding!");
							message("");
						}
					} else {
						QueryNotSeen(numID);
					}
	
				} else if (request_Info[0].equals("QUERYHIT")) {
					String msgID = request_Info[1];
					String fileNm = request_Info[3];
					String fetch_IP = request_Info[4];
					String fetch_NUMID = request_Info[5];
					String msgOwner = msgID.split("##")[0];
					if (this.numID.equals(msgOwner)) {
						synchronized (queryMAP) {
	
							if (!queryMAP.containsKey(fileNm)) {
								int j_ = 1;
								queryMAP.put(fileNm, j_);
	
							} else {
	
								queryMAP.put(fileNm, queryMAP.get(fileNm) + 1);
	
							}
						}
	
						if (queryMAP.get(fileNm) > 1) {
	
				message(this.numID + "---Client: Thanks for information. I already have----" + fileNm+ "----");
							message("");
	
						} else {
							
							workElse(this.numID, fileNm);
	
							Runnable FiletoReceive = new FileReceiver(fetch_NUMID, fetch_IP, fileNm, this.numID);
							Thread FiletoReceiveThread = new Thread(FiletoReceive);
							FiletoReceiveThread.start();
	
						}
	
					} else {
	
	
						message(this.numID + "---Client: we are receiving from QUERYHIT which " + fetch_NUMID
								+ "---Client has the file " + fileNm + " you want----");
						message("");
						String previous_IP_PORT = map.get(msgID);
						String previous_IP = previous_IP_PORT.split(":")[0];
						String previous_PORT = previous_IP_PORT.split(":")[1];
						int ip = Integer.parseInt(previous_PORT);
						workSocket(previous_IP, ip, resp);
					}
	
				} else if (request_Info[0].equals("MISS")) {
	
					String msgID = request_Info[1];
					String fl_nm = request_Info[2];
					String missedSenderID = request_Info[3];
					String msgOwner = msgID.split("##")[0];
					if (this.numID.equals(msgOwner)) {
	
						message("---Client" +this.numID+ ":  ---Your neigbhour client(" +missedSenderID+ "doesn't have the file  " + fl_nm + "----");
						message("");
	
					} else {
						// Back forward
	
						message(this.numID + "---Client: we are receiving from MISS which " + missedSenderID
								+ "---Client doesn't have the file  " + fl_nm + "----");
						message("");
						String pIPPort = map.get(msgID);
						String p_IP = pIPPort.split(":")[0];
						String p_PORT = pIPPort.split(":")[1];
						int portnumber = Integer.parseInt(p_PORT);
						workSocket(p_IP, portnumber, resp);
						
					}
				}
	
			} catch (Exception e) {
				e.printStackTrace();
			}
	
		}
	
		public static void workElse(String numID,String fileNm)
		{
			message("---Client"+numID+": You are the first one to let me download " + fileNm
					+ " Let's communicate-----");
			message("");
			message("---Client"+numID+": I'm downloading " + fileNm + "-----");
			message("");
			message("---Client"+numID+": We are creating a new thread to fetch the file -----");
			message(" ");
		}
		public static void QueryNotSeen(String numID) {
			message("---Client" + numID + ":Already seen the message.");
			message("");
		}
	
		public static void workSocket(String prevs_NumberID, int prevs_IP, String Miss_message)
				throws UnknownHostException, IOException {
			Socket socket;
			socket = new Socket(prevs_NumberID, (prevs_IP));
			BufferedReader input;
			input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintStream output;
			output = new PrintStream(socket.getOutputStream());
	
			output.println(Miss_message);
			output.flush();
			socket.close();
	
		}
	
		/***
		 *  Scan all the local client files
		 * 
		 * @param fp
		 * @return
		 */
		public static ArrayList<String> scan_files(String fp) {
	
			ArrayList<String> FileList = new ArrayList<String>();
			File[] filelist = new File(fp).listFiles();
	
			for (int j = 0; j < filelist.length; j++) {
	
				FileList.add(filelist[j].getName());
			}
	
			return FileList;
		}
		public String get_IP() {
	
			InetAddress ip;
	
			try {
				ip = InetAddress.getLocalHost();
				return ip.getHostAddress();
	
			} catch (Exception e) {
				e.printStackTrace();
				return "localhost";
			}
		}
		public static void message(String message) {
			System.out.println(message);
		}
		public void sendReqNbr(HashMap<String, String> nbrIP, String flName, String msg, String currNID, int curr_TTL,
				String prev_Sender) throws Exception {
	
			for (String key : nbrIP.keySet()) {
	
				if (key.equals(prev_Sender)) {
	
					message("---Client" + this.numID + ": Not seding query back to previous----");
					message("");
	
				} else {
	
					message("---Client" + this.numID + ": Forwarding to " + key + "----");
					message("");
					int current_port = Integer.parseInt(key) + START_SEARCH_PORT;
					String current_ip = nbrIP.get(key);
					String query_message = "QUERY%" + msg + "%" + Integer.toString(curr_TTL) + "%" + flName + "%" + currNID;
	
					workSocket(current_ip, current_port, query_message);
				}
			}
		}
	
	}
	
	
	class PeerServer implements Runnable {
	
		final static int START_SEARCH_PORT = 6410;
		final static int START_FILE_REQ_PORT = 6530;
		final static int START_FILE_PORT = 6650;
		int port_num;
		int portnum_file;
		String clientName;
	
		PeerServer(String NumID, String peername) throws IOException {
	
			this.port_num = Integer.parseInt(NumID) + START_FILE_REQ_PORT;
			this.clientName = peername;
			this.portnum_file = Integer.parseInt(NumID) + START_FILE_PORT;
	
		}
	
		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
	
				ServerSocket srvrSocket = new ServerSocket(port_num);
				ServerSocket FileRequest = new ServerSocket(portnum_file);
	
				while (true) {
	
					
					printMsg("---Client"+clientName+": I'm waiting for your retrieving file request.");
					printMsg(" ");
	
					Socket serviceSocket = srvrSocket.accept();
					Runnable senderFile = new FileSender(serviceSocket, clientName, FileRequest);
					Thread thread = new Thread(senderFile);
					thread.start();
				}
	
			} catch (Exception e) {
						e.printStackTrace();
			}
	
		}
	
		public void printMsg(String msg) {
			System.out.println(msg);
		}
	}
	class FileSender implements Runnable {
	
		private static final boolean TRUE = true;
		Socket recReq;
		String path;
		ServerSocket fileReq;
		String nameClient;
	
		FileSender(Socket receivesocket, String peername, ServerSocket FileRequest) {
	
			this.fileReq = FileRequest;
			this.path = "./docs/" + peername + "/";
			this.nameClient = peername;
			this.recReq = receivesocket;
			
		}
	
		public void run() {
	
			try {
	
				BufferedReader in = new BufferedReader(new InputStreamReader(recReq.getInputStream()));
				PrintWriter out = new PrintWriter(recReq.getOutputStream(), true);
				showMsg("---Client"+nameClient + ": Which File you need?");
				showMsg(" ");
				String resp = "";
	
				while (!(resp.equals("HELLO"))) {
	
					resp = in.readLine();
					showMsg("---Client"+nameClient + ": Get the messages: " + resp);
					showMsg(" ");
	
					if (resp.equals("HELLO")) {
						out.println("HELLO");
						showMsg("---Client"+nameClient + ": Send the messages: " + resp);
						showMsg(" ");
						out.flush();
					}
	
				}
	
				while (!(resp.equals("CLOSE"))) {
	
					resp = in.readLine();
					String[] reqInfo = resp.split(" ");
	
					if (reqInfo[0].equals("RETRIEVE")) {
	
						Socket fileReqSocket = fileReq.accept();
						String fl_name = reqInfo[1];
						String filePath = path + reqInfo[1];
						out.println("OK");
						out.flush();
	
						File sentFile = new File(filePath);
						synchronized (sentFile) {
							byte[] bt = new byte[(int) sentFile.length()];
							BufferedInputStream bfrinputStream = new BufferedInputStream(new FileInputStream(sentFile));
							bfrinputStream.read(bt, 0, bt.length);
							BufferedOutputStream outStream = new BufferedOutputStream(fileReqSocket.getOutputStream());
							outStream.write(bt, 0, bt.length);
							outStream.flush();
	
						}
	
						showMsg("---Client"+nameClient + ": The file " + fl_name + " is sent.");
						showMsg(" ");
	
					}
				}
	
				showMsg("---Client"+nameClient + ": Exiting current sending thread.");
				showMsg(" ");
	
				out.println("CLOSE");
				out.flush();
	
				recReq.close();
	
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
	
			}
	
		}
	
		public void showMsg(String message) {
			System.out.println(message);
		}
	
	}
	class FileReceiver implements Runnable {
	
		final static int START_SEARCH_PORT = 6410;
		final static int START_FILE_REQUEST_PORT = 6530;
		final static int START_FILE_PORT = 6650;
	
		int fileSenderPort;
		String fileSenderAdd;
		String FileName;
		final static String FileSize = "999999999";
		String curr_ClientNAme;
		String fp;
		String senderClientName;
	
		FileReceiver(String SenderNumID, String PeerFileSenderAdd, String FileName, String NumID) {
			this.senderClientName = SenderNumID;
			this.fileSenderPort = Integer.parseInt(SenderNumID) + START_FILE_REQUEST_PORT;
			this.FileName = FileName;
			this.curr_ClientNAme = NumID;
			this.fileSenderAdd = PeerFileSenderAdd;
			this.fp = "./docs/" + curr_ClientNAme + "/" + FileName;
		}
	
		public void run() {
	
			try {
	
				int byteRead;
				
				int clientFileSenderPort = START_FILE_PORT + Integer.parseInt(senderClientName);
	
				Socket reqSocket = new Socket(fileSenderAdd, fileSenderPort);
				Socket reqRecSocket = new Socket(fileSenderAdd, clientFileSenderPort);
	
				BufferedReader inputReader = new BufferedReader(new InputStreamReader(reqSocket.getInputStream()));
				PrintWriter printWriter = new PrintWriter(reqSocket.getOutputStream());
	
				log("---Client "+curr_ClientNAme+": Receiving file " + FileName + " from " + senderClientName);
				log(" ");
	
				printWriter.println("HELLO");
				printWriter.flush();
	
				String Hello = "RETRIEVE "+FileName;
				printWriter.println(Hello);
				printWriter.flush();
	
				String hello = inputReader.readLine();
	
				if (inputReader.readLine().equals("OK")) {
					java.io.InputStream fileIn = reqRecSocket.getInputStream();
					PrintWriter fileoutForSender = new PrintWriter(reqRecSocket.getOutputStream(), true);
					long start_Time = System.currentTimeMillis();
					synchronized (new File(fp)) {
						BufferedOutputStream file_Out = new BufferedOutputStream(new FileOutputStream(new File(fp)));
						byte[] buffer = new byte[Integer.parseInt(FileSize)];
						byteRead = fileIn.read(buffer, 0, buffer.length);
						log("---Client"+curr_ClientNAme +": I'm receiving the file " + FileName);
						log("");
						file_Out.write(buffer, 0, byteRead);
						file_Out.flush();
					}
	
					log(curr_ClientNAme + "---Client: File " + fp + " downloaded (" + byteRead
							+ " bytes read)");
	
					long stop_Time = System.currentTimeMillis();
	
					System.out.println(curr_ClientNAme + "---Client: transfer speed: "
							+ (double) byteRead / 1000 / (stop_Time - start_Time) + " Mb/sec.");
	
					printWriter.println("CLOSE");
					printWriter.flush();
	
					while (true) {
						if (inputReader.readLine().equals("CLOSE")) {
							reqSocket.close();
							reqRecSocket.close();
							break;
						} else {
							continue;
						}
					}
	
				}
	
			} catch (IOException e) {
				e.printStackTrace();
			}
	
		}
	
		public void log(String message) {
			System.out.println(message);
		}
	
	}
